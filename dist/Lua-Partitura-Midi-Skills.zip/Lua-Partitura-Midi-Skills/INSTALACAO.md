# Instalação das Skills Lua

Este pacote contém duas habilidades independentes e complementares:

- `transcrever-musica-para-midi`: transforma áudio musical em MIDI multifaixa auditado, com reconstrução por instrumento;
- `escrever-partituras-corretamente`: cria, corrige e valida partituras em MusicXML/MXL, LilyPond, MIDI e PDF.

Cada pasta é uma Skill completa. Preserve sua estrutura interna: o arquivo `SKILL.md` deve permanecer na raiz da respectiva pasta, ao lado de `agents/`, `assets/`, `references/` e `scripts/`.

## ChatGPT Work

Quando a área de Skills estiver habilitada para a conta ou workspace:

1. Abra uma conversa normal no ChatGPT Work.
2. Anexe este ZIP sem descompactá-lo.
3. Escreva: `@skill-creator Instale e valide as duas habilidades contidas neste arquivo.`
4. Depois da confirmação, abra **Plugins → Skills** e atualize a lista, se necessário.
5. Para chamar uma habilidade diretamente, digite `@` e escolha seu nome.

## Codex CLI, aplicativo desktop ou extensão de IDE

Descompacte o ZIP e copie as duas pastas de habilidade para `$HOME/.agents/skills/`. Para limitar as Skills a um projeto, copie-as para `.agents/skills/` na raiz do repositório.

Confirme que cada caminho termina em:

```text
.../transcrever-musica-para-midi/SKILL.md
.../escrever-partituras-corretamente/SKILL.md
```

No Codex CLI ou na extensão de IDE, use `/skills` ou digite `$` para selecionar uma habilidade.

## Outras plataformas de IA

Em plataformas compatíveis com Agent Skills, importe cada pasta como uma habilidade separada e preserve toda a estrutura interna. Em plataformas sem esse padrão, use `SKILL.md` como instrução operacional e disponibilize `references/`, `scripts/` e `assets/` no ambiente de arquivos do agente.

## Uso direto

```text
Use @transcrever-musica-para-midi para transcrever este áudio em MIDI multifaixa e auditar o resultado.
```

```text
Use @escrever-partituras-corretamente para produzir MusicXML e PDF, revisar a notação e executar a auditoria final.
```

No Codex, substitua `@` por `$` na menção explícita.

## Observações

- Os auditores incluídos usam somente a biblioteca-padrão do Python.
- Backends externos de separação, transcrição e renderização não são incorporados ao pacote.
- A qualidade final exige reconciliação musical e controle auditivo; uma saída automática não é considerada correta apenas porque abriu em um programa.

O projeto é dedicado ao domínio público por meio de The Unlicense. É livre para copiar, modificar, publicar, usar e distribuir, sem autorização ou atribuição obrigatória. Dependências externas mantêm suas próprias licenças.
